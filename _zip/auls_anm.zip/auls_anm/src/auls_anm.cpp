////////////////////////////////////////////////////////////////////////////////
// auls_anm.cpp
// �A�j���[�V�������ʗpDLL
////////////////////////////////////////////////////////////////////////////////

#include <yulib/generic.h>
#include <aulslib/lua.h>

using namespace yulib;
using namespace auls;

// �J���[�ʃG�b�W
int l_ColorEmboss(lua_State *L)
{
	// stack
	// 1, 2 : ���F�A�ÐF
	// 3-6  : ���摜�f�[�^�A�ʃG�b�W�摜�f�[�^�A���A����
	// �ʃG�b�W�摜�f�[�^�� R �Ŗ��F�AG �ňÐF�̕ω��ʂ��v�Z����B
	ColorRGB light_col = lua_tointeger(L, 1), dark_col = lua_tointeger(L, 2);
	luaA_PixelData2 pd(L, 3);
	lua_pop(L, 3);

	for(int i = pd.Size(); i;) {
		i--;
		ColorRGBA basecol = pd.data1[i], ecol = pd.data2[i];
		ColorRGBA usecol;
		if(ecol.r != 0) { usecol = light_col; usecol.a = ecol.r; }
		else if(ecol.g != 255) { usecol = dark_col; usecol.a = 255 - ecol.g; }
		else continue;
		basecol.r = (basecol.r * (255 - usecol.a) + usecol.r * usecol.a) / 255;
		basecol.g = (basecol.g * (255 - usecol.a) + usecol.g * usecol.a) / 255;
		basecol.b = (basecol.b * (255 - usecol.a) + usecol.b * usecol.a) / 255;
		pd.data1[i] = basecol;
	}

	return 1;
}

void ReduceColor_Normal(luaA_TableArgs<ColorRGB> &cols, luaA_PixelData &pd)
{
	for(int i = pd.Size(); i;) {
		i--;
		int col_index = 0;
		int score = Diff(pd[i].r, cols[0].r) + Diff(pd[i].g, cols[0].g) + Diff(pd[i].b, cols[0].b);
		for(int j = 1; j < cols.num; j++) {
			int score_temp = Diff(pd[i].r, cols[j].r) + Diff(pd[i].g, cols[j].g) + Diff(pd[i].b, cols[j].b);
			if(score_temp < score) {
				col_index = j;
				score = score_temp;
			}
		}
		pd[i] = cols[col_index];
	}
}

void ReduceColor_CarryOver(luaA_TableArgs<ColorRGB> &cols, luaA_PixelData &pd)
{
	int r_carry = 0, g_carry = 0, b_carry = 0;
	for(int i = pd.Size(); i;) {
		i--;
		ColorRGB org = pd[i];
		if(r_carry < 0 && org.r < -r_carry) { r_carry += org.r; org.r = 0; }
		else if(r_carry > 0 && (255 - org.r) < r_carry) { r_carry -= org.r; org.r = 255; }
		else org.r += r_carry;
		if(g_carry < 0 && org.g < -g_carry) { g_carry += org.g; org.g = 0; }
		else if(g_carry > 0 && (255 - org.g) < g_carry) { g_carry -= org.g; org.g = 255; }
		else org.g += g_carry;
		if(b_carry < 0 && org.b < -b_carry) { b_carry += org.b; org.b = 0; }
		else if(b_carry > 0 && (255 - org.b) < b_carry) { b_carry -= org.b; org.b = 255; }
		else org.b += b_carry;

		int col_index = 0;
		int score = Diff(org.r, cols[0].r) + Diff(org.g, cols[0].g) + Diff(org.b, cols[0].b);
		for(int j = 1; j < cols.num; j++) {
			int score_temp = Diff(org.r, cols[j].r) + Diff(org.g, cols[j].g) + Diff(org.b, cols[j].b);
			if(score_temp < score) {
				col_index = j;
				score = score_temp;
			}
		}
		r_carry = pd[i].r - cols[col_index].r;
		g_carry = pd[i].g - cols[col_index].g;
		b_carry = pd[i].b - cols[col_index].b;
		pd[i] = cols[col_index];
	}
}

// �F�w�茸�F
int l_ReduceColor(lua_State *L)
{
	// stack
	// 1 : �v�Z����
	// 2 : �F���e�[�u��
	// 3-5 : �s�N�Z���f�[�^����
	int calctype = lua_tointeger(L, 1);
	luaA_TableArgs<ColorRGB> cols(L, 2, luaA_todword);
	luaA_PixelData pd(L, 3);

	switch(calctype) {
		case 0:
		default: ReduceColor_Normal(cols, pd); break;
		case 1: ReduceColor_CarryOver(cols, pd); break;
	}

	return 3;
}

////////////////////////////////////////////////////////////////////////////////
// �֐��o�^
////////////////////////////////////////////////////////////////////////////////

#define R(name) { #name, l_##name }
const luaL_reg table[] = {
	R(ColorEmboss),
	R(ReduceColor),
	{ NULL, NULL },
};

extern "C" __declspec(dllexport) int luaopen_auls_anm(lua_State *L)
{
	luaA_register(L, "auls", "anm", table);
	return 1;
}
